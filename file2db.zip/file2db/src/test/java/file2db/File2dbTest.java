package file2db;

import junit.framework.TestCase;

public class File2dbTest extends TestCase {

    public void testMain() {
    }
}