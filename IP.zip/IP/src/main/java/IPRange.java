
public class IPRange {

    public static int ipToInt(int ip[]) {
        return ((ip[0]*256 + ip[1])*256 + ip[2])*256 + ip[3];
    }

    public static String intToIp(long i) {
        return ((i >>> 24) & 0xFF) + "." +
                ((i >>> 16) & 0xFF) + "." +
                ((i >>>  8) & 0xFF) + "." +
                ((i >>> 0) & 0xFF);
    }

    public static void main(String[] args) {
        int[] ip1 = new int[4];
        ip1[0] = 192;
        ip1[1] = 168;
        ip1[2] = 0;
        ip1[3] = 1;
        int[] ip2 = new int[4];
        ip2[0] = 192;
        ip2[1] = 168;
        ip2[2] = 0;
        ip2[3] = 5;
        long i1;
        long i2;
        i1 = ipToInt(ip1);
        i2 = ipToInt(ip2);
        for (long i = ++i1; i < i2; i++) {
            String result = new String(intToIp(i));
            System.out.println(result);
        }

    }

}