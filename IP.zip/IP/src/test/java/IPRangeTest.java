import junit.framework.TestCase;

public class IPRangeTest extends TestCase {

    public void testIpToInt() {
    }

    public void testIntToIp() {
    }

    public void testMain() {
    }
}